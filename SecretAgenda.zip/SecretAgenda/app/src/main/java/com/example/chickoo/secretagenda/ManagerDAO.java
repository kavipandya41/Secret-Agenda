package com.example.chickoo.secretagenda;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class ManagerDAO extends SQLiteOpenHelper
{

    public ManagerDAO(Context context)
    {
        super(context, "Manager", null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String sql1 = "Create table manager (email TEXT PRIMARY KEY,password TEXT);";
        db.execSQL(sql1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {
        String sql2 = "DROP TABLE IF EXISTS manager;";
        db.execSQL(sql2);
    }
    private ContentValues getContentValues(Manager manager)
    {
        ContentValues managerData = new ContentValues();
        managerData.put("email", manager.getEmail());
        managerData.put("password", manager.getPassword());
        return managerData;
    }
    public void dbinsert(Manager manager)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues managerData = new ContentValues();
        managerData.put( "email",manager.getEmail() );
        managerData.put( "password",manager.getPassword() );
        db.insert("manager",null,managerData);
    }
    public List<Manager> dbSearch()
    {
        String sql="SELECT * FROM manager;";
        SQLiteDatabase db=getReadableDatabase();
        Cursor c=db.rawQuery(sql,null);

        List<Manager>managerList = new ArrayList<Manager>();
        if(c.moveToFirst()) {
            do
            {
                Manager manager = new Manager();
                manager.setEmail(c.getString(c.getColumnIndex("email")));
                manager.setPassword(c.getString(c.getColumnIndex("password")));
                managerList.add(manager);
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return managerList;
    }
}
