package com.example.chickoo.secretagenda;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.w3c.dom.NameList;

import java.util.ArrayList;
import java.util.List;

public class AgentList extends AppCompatActivity
{
    ListView agentList;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_agent_list );
    }
    private void LoadAgentList()
    {
        AgentDAO agentDAO = new AgentDAO( AgentList.this );
        ArrayList<Agent> agents = agentDAO.dbsearch();
        agentDAO.close();
        agentList = (ListView) findViewById( R.id.agentList );
        ArrayAdapter<Agent> adapter = new ArrayAdapter<Agent>( AgentList.this, android.R.layout.activity_list_item, agents );
        agentList.setAdapter( adapter );
    }
    protected void onResume()
    {
        LoadAgentList();
        super.onResume();
    }
    public void onCreateContextMenu(ContextMenu menu, View v,final ContextMenu.ContextMenuInfo menuInfo)
    {
        AdapterContextMenuInfo info = (AdapterContextMenuInfo)menuInfo;
        final Agent agent = (Agent) agentList.getItemAtPosition(info.position);
    }
}
