package com.example.chickoo.secretagenda;

import android.widget.EditText;

/**
 * Created by chickoo on 12/13/2017.
 */

public class FormHelper
{
    private final EditText name;
    private final EditText level;
    private final EditText agency;
    private final EditText website;
    private final EditText country;
    private final EditText phone;
    private final EditText address;

    public FormHelper(Agent_Entry activity)
    {
        name = (EditText) activity.findViewById(R.id.profile_name);
        level = (EditText) activity.findViewById(R.id.profile_level);
        agency = (EditText) activity.findViewById(R.id.profile_agency);
        website = (EditText) activity.findViewById(R.id.profile_website);
        country = (EditText) activity.findViewById(R.id.profile_country);
        phone = (EditText) activity.findViewById(R.id.profile_phone);
        address = (EditText) activity.findViewById(R.id.profile_address);
    }
    public Agent helperAgent()
    {
        Agent agent = new Agent();
        agent.setName(name.getText().toString());
        agent.setLevel(level.getText().toString());
        agent.setAgency(agency.getText().toString());
        agent.setWebsite(website.getText().toString());
        agent.setCountry(country.getText().toString());
        agent.setAddress(address.getText().toString());
        return agent;
    }
}
