package com.example.chickoo.secretagenda;

import android.widget.EditText;

public class ManagerHelper
{
    private final EditText email;
    private final EditText password;

    public ManagerHelper(Manager_Register activity)
    {
        email = (EditText) activity.findViewById( R.id.email );
        password = (EditText) activity.findViewById( R.id.password );
    }
    public Manager helperManager()
    {
        Manager manager = new Manager();
        manager.setEmail( email.getText().toString() );
        manager.setPassword( password.getText().toString() );
        return  manager;
    }
}
