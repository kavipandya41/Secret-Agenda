package com.example.chickoo.secretagenda;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Agent_Entry extends AppCompatActivity
{
    private  EditText name;
    private  EditText level;
    private  EditText agency;
    private  EditText website;
    private  EditText country;
    private  EditText phone;
    private  EditText address;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_agent__entry );
        name = (EditText) findViewById(R.id.profile_name);
        level = (EditText) findViewById(R.id.profile_level);
        agency = (EditText) findViewById(R.id.profile_agency);
        website = (EditText) findViewById(R.id.profile_website);
        country = (EditText) findViewById(R.id.profile_country);
        phone = (EditText) findViewById(R.id.profile_phone);
        address = (EditText) findViewById(R.id.profile_address);
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_form, menu);

        return super.onCreateOptionsMenu(menu);
    }


    public void getCodeInsert(View view) {
        Agent agent = new Agent();
        agent.setName(name.getText().toString());
        agent.setLevel(level.getText().toString());
        agent.setAgency(agency.getText().toString());
        agent.setWebsite(website.getText().toString());
        agent.setCountry(country.getText().toString());
        agent.setAddress(address.getText().toString());
        AgentDAO dao = new AgentDAO(this);
        int a=dao.dbinsert(agent);
        dao.close();
        if(a>0){
            Toast.makeText( Agent_Entry.this, "Data Inserted", Toast.LENGTH_SHORT ).show();
        }else{
            Toast.makeText( Agent_Entry.this, "Data not Inserted", Toast.LENGTH_SHORT ).show();
        }
    }
}
