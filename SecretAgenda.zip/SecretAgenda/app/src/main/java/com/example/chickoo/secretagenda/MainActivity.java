package com.example.chickoo.secretagenda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        Button login=(Button)findViewById(R.id.login);
        Button register=(Button)findViewById(R.id.register);
        final EditText email = (EditText) findViewById( R.id.email );
        final EditText password = (EditText) findViewById( R.id.password );
        ManagerDAO managerDAO = new ManagerDAO( MainActivity.this );
        register.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent i=new Intent(MainActivity.this,Manager_Register.class);
                startActivity(i);
            }
        });
        login.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v)
            {

                List<Manager> managerList = loadManager();

                final String uEmail = email.getText().toString();
                final String uPassword = password.getText().toString();
                if(uEmail.isEmpty() || uPassword.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Enter Login Credentials !!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if (managerList.isEmpty())
                    {
                        Toast.makeText(MainActivity.this, "Register First", Toast.LENGTH_SHORT).show();
                    }
                    for (int i=0; i<managerList.size(); i++)
                    {
                        String userEmail=managerList.get(i).getEmail();
                        String userPassword=managerList.get(i).getPassword();
                        //Toast.makeText(WelcomeActivity.this, userName, Toast.LENGTH_SHORT).show();
                        if(uEmail.equals(userEmail)&& uPassword.equals(userPassword))
                        {
                            Intent goToAgents = new Intent( MainActivity.this, AgentInfo.class );
                            Toast.makeText( MainActivity.this, "Successfully Logged In..", Toast.LENGTH_SHORT ).show();
                            goToAgents.putExtra( "email", userEmail );
                            startActivity( goToAgents );
                            break;
                        }
                        else
                        {
                            Toast.makeText( MainActivity.this, "Incorrect Username or Password", Toast.LENGTH_SHORT ).show();
                        }
                    }
                }
            }
        });
    }
    public List<Manager> loadManager()
    {
        ManagerDAO managerDAO = new ManagerDAO(this);
        List<Manager> managers = managerDAO.dbSearch();
        managerDAO.close();
        return managers;
    }
}
