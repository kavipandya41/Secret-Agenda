package com.example.chickoo.secretagenda;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class AgentDAO extends SQLiteOpenHelper
{
    public AgentDAO(Context context)
    {
        super(context, "MyAgents", null,1);
    }
    public void onCreate(SQLiteDatabase db)
    {
        String sql1 = "Create table agents (name TEXT not null,level TEXT,agency TEXT,website TEXT,country TEXT,phone TEXT primary key,address TEXT,photopath TEXT);";
        db.execSQL(sql1);
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        String sql2 = "DROP TABLE IF EXISTS agents;";
        db.execSQL(sql2);
    }
    private ContentValues getContentValues(Agent agent)
    {
        ContentValues agentData = new ContentValues();
        agentData.put("name",agent.getName());
        agentData.put("level",agent.getLevel());
        agentData.put("agency",agent.getAgency());
        agentData.put("website",agent.getWebsite());
        agentData.put("country",agent.getCountry());
        agentData.put("phone",agent.getPhone());
        agentData.put("address",agent.getAddress());
        agentData.put("photopath",agent.getPhotopath());
        return agentData;
    }
    public int dbinsert(Agent agent)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues agentData = new ContentValues();
        agentData.put("name",agent.getName());
        agentData.put("level",agent.getLevel());
        agentData.put("agency",agent.getAgency());
        agentData.put("website",agent.getWebsite());
        agentData.put("country",agent.getCountry());
        agentData.put("phone",agent.getPhone());
        agentData.put("address",agent.getAddress());
        agentData.put("photopath",agent.getName());

        int a=(int)db.insert("agents",null,agentData);
        return a;

    }
    public ArrayList<Agent> dbsearch()
    {
        SQLiteDatabase db = getReadableDatabase();
        String sql3 = "SELECT * FROM AGENTS;";
        Cursor c = db.rawQuery(sql3, null);
        ArrayList<Agent> AgentList = new ArrayList<Agent>();
        while (c.moveToNext())
        {
            Agent agent = new Agent();
            agent.setName(c.getString(c.getColumnIndex("name")));
            agent.setLevel(c.getString(c.getColumnIndex("level")));
            agent.setAgency(c.getString(c.getColumnIndex("agency")));
            agent.setWebsite(c.getString(c.getColumnIndex("website")));
            agent.setCountry(c.getString(c.getColumnIndex("country")));
            agent.setPhone(c.getString(c.getColumnIndex("phone")));
            agent.setAddress(c.getString(c.getColumnIndex("address")));
            agent.setPhotopath(c.getString(c.getColumnIndex("photopath")));
            AgentList.add(agent);
        }
        c.close();
        return AgentList;
    }
    public void dbdelete(Agent agent)
    {
        SQLiteDatabase db = getWritableDatabase();
        String[] param = {agent.getPhone().toString()};
        db.delete("agents", "phone = ?", param);
    }
    public void dbalter(Agent agent)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues agentData = getContentValues(agent);
        String[] param = {agent.getPhone().toString()};
        db.update("agents",agentData , "phone = ?", param);
    }
}
