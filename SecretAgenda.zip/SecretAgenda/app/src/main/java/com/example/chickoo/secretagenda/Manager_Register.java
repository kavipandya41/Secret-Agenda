package com.example.chickoo.secretagenda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Manager_Register extends AppCompatActivity
{
    EditText email;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_manager__register );
        Button register = (Button) findViewById( R.id.register );
        email = (EditText) findViewById( R.id.email );
        password = (EditText) findViewById( R.id.password );
        register.setOnClickListener( new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Manager manager = new Manager();
                String memail = email.getText().toString();
                String mpassword = password.getText().toString();
                manager.setEmail(memail);
                manager.setPassword(mpassword);
                ManagerDAO managerDAO = new ManagerDAO( Manager_Register.this );
                managerDAO.dbinsert( manager );
                managerDAO.close();

                Intent intent = new Intent( Manager_Register.this, MainActivity.class );
                startActivity( intent );
            }
        } );
    }
}
