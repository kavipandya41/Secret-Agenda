package com.example.chickoo.secretagenda;

public class Agent
{
    private String name;
    private String agency;
    private String level;
    private String website;
    private String country;
    private String address;
    private String phone;
    private String photopath;

    public String getPhotopath()
    {
        return photopath;
    }

    public void setPhotopath(String photopath)
    {
        this.photopath = photopath;
    }

    public String getAgency()
    {
        return agency;
    }
    public void setAgency(String agency)
    {
        this.agency = agency;
    }
    public String getLevel()
    {
        return level;
    }
    public void setLevel(String level)
    {
        this.level = level;
    }
    public String getWebsite()
    {
        return website;
    }
    public void setWebsite(String website)
    {
        this.website = website;
    }
    public String getCountry()
    {
        return country;
    }
    public void setCountry(String country)
    {
        this.country = country;
    }
    public String getAddress()
    {
        return address;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }
    public String getPhone()
    {
        return phone;
    }
    public void setPhone(String phone)
    {
        this.phone = phone;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
}
